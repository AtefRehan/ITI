import { Shape } from "./shape.js";
export class Triangle extends Shape {
  #base;
  #height;

  constructor(base, height) {
    super();
    this.#height = height;
    this.#base = base;
  }
  calcArea() {
    return 0.5 * (this.#base * this.#height);
  }

  get height() {
    return this.#height;
  }
  
}
