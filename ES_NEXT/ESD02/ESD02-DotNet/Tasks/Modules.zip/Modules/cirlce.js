import { Shape } from "./shape.js";
export class Circle extends Shape {
#radius ;
constructor(radius){
    super();
    this.#radius = radius;
}

    calcArea() {
        return Math.PI*this.#radius*this.#radius;
    }
}