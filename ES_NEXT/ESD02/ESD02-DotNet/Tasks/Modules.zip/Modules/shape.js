export class Shape{ 
    
    calcArea(){
        return 0;
    }
}